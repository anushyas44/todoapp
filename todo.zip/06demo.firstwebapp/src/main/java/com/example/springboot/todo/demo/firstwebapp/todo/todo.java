package com.example.springboot.todo.demo.firstwebapp.todo;

import java.time.LocalDate;


public class todo {

	private int id;
	private String username;
	private String description;
	private LocalDate localdate;
	private boolean done;

	public todo(int id, String username, String description, LocalDate localdate, boolean done) {
		super();
		this.id = id;
		this.username = username;
		this.description = description;
		this.localdate = localdate;
		this.done = done;
	}

	public int getid() {
		return id;
	}

	public void setid(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getlocaldate() {
		return localdate;
	}

	public void setlocaldate(LocalDate targetdate) {
		this.localdate = targetdate;
	}

	public boolean isDone() {
		return done;
	}

	public void setDone(boolean done) {
		this.done = done;
	}

	@Override
	public String toString() {
		return "todo [id=" + id + ", username=" + username + ", description=" + description + ", localdate=" + localdate
				+ ", done=" + done + "]";
	}

	
}
