package com.example.springboot.todo.demo.firstwebapp.login;

import org.springframework.stereotype.Service;

@Service
public class loginaunthendication {
	
	public boolean validuser(String name, String password) {
		
		boolean isusername = name.equalsIgnoreCase("sk");
		boolean ispas = password.equals("123");
		
		return isusername && ispas;
		
	}

}
