package com.example.springboot.todo.demo.firstwebapp.todo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.springframework.stereotype.Service;

@Service
public class todoservice {

	static List<todo> todos = new ArrayList<>();

	static int todocount = 0;

	static {
		todos.add(new todo(++todocount, "sara", "java course", LocalDate.now().plusYears(1), true));
		todos.add(new todo(++todocount, "sara", "spring course", LocalDate.now().plusMonths(2), true));
		todos.add(new todo(++todocount, "sara", "AWS course", LocalDate.now().plusYears(3), true));
	}

	public List<todo> findbyauthor() {

		return todos;
	}

	public void addTodo(String username, String description, LocalDate localdate, boolean done) {

		todo todo = new todo(++todocount, username, description, localdate, done);
		todos.add(todo);
	}

	public void deletebyid(int id) {
		Predicate<? super todo> pre = todo -> todo.getid() == id;

		todos.removeIf(pre);
	}

	public todo updatebyid(int id) {
		Predicate<? super todo> pre = todo -> todo.getid() == id;
		todo todo =todos.stream().filter(pre).findFirst().get();
		return todo;
	}
}
