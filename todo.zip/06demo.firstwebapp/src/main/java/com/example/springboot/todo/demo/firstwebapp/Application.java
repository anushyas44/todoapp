package com.example.springboot.todo.demo.firstwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@ComponentScan("package com.example.springboot.todo.demo.hellopage")
//@ComponentScan("package com.example.springboot.todo.demo.firstwebapp.login")
@ComponentScan("com.example.springboot.todo.demo.*")
public class Application {

	public static void main(String[] args) {
		var context = SpringApplication.run(Application.class, args);
		//context.getBean(hellopage.class);
	
		//context.getBean("logincontroller.class");
}

}
