package com.example.springboot.todo.demo.hellopage;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class hellopage {

	@RequestMapping("hello")
//	@ResponseBody
	public String hello() {
		return "Hello.. welcome to login page..";
	}

	@RequestMapping("hellohtml")
//	@ResponseBody
	public String hellohtml() {
		StringBuffer sb = new StringBuffer();
		sb.append("<html>");
		sb.append("<body>");
		sb.append("<H1>HTML_ page</H1>");
		sb.append("</body>");
		sb.append("</html>");
		sb.append("");
		return sb.toString();
	}

	@RequestMapping("hellojsp")
	public String hellojsp() {
		return "login";
	}

//	@RequestMapping("login")
//	public String login(@RequestParam String name, ModelMap model) {
//
//		model.put(name, name);
//
//		System.out.println(name);
//		return "dummy";
//	}
}
