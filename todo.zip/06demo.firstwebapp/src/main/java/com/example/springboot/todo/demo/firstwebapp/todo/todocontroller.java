package com.example.springboot.todo.demo.firstwebapp.todo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("name")
public class todocontroller {

	private todoservice todoser;

	@Autowired
	public todocontroller(todoservice todoser) {
		super();
		this.todoser = todoser;
	}

	@RequestMapping("listdoto")
	public String listtodo(ModelMap model) {
		List<todo> todo = todoser.findbyauthor();
		model.addAttribute("todos", todo);
		return "todolist";
	}

	@RequestMapping(value = "add-todo", method = RequestMethod.GET)
	public String shownewtodo() {
		return "todo";
	}

	@RequestMapping(value = "add-todo", method = RequestMethod.POST)
	public String addNewTodo(@RequestParam String description, ModelMap model) {
		String username = (String) model.get("name");
		todoser.addTodo(username, description, LocalDate.now(), false);
		return "redirect:listdoto";
	}

	@RequestMapping(value = "delete-todo")
	public String deleteTodo(@RequestParam int id) {
		todoser.deletebyid(id);

		return "redirect:listdoto";
	}

	@RequestMapping(value = "update-todo")
	public String updateTodo(@RequestParam int id, ModelMap model) {
		todoser.updatebyid(id);
		model.addAttribute("todo", todoser);

		return "todo";
	}
}
