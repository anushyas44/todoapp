create table student
(

	id int not null,
	name varchar(255) not null,
	address varchar(255),
	primary key (id)


);