package com.example.jpa.demo.jpa;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.jpa.demo.jpa.student.student;

@Repository
public interface springdatajpa_ex extends JpaRepository<student, Long> {

}
