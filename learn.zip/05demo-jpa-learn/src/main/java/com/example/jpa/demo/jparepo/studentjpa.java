package com.example.jpa.demo.jparepo;

import org.springframework.stereotype.Repository;

import com.example.jpa.demo.jpa.student.student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class studentjpa {
	
	@PersistenceContext
	private EntityManager entitymanager;
	
	public void insert(student s) {
		entitymanager.merge(s);
	}
	
	public void find(int id) {
		System.out.println(entitymanager.find(student.class, id));
	}
	
	public void delete(int id) {
		student s = entitymanager.find(student.class, id);
		entitymanager.remove(s);
	}
	
}
