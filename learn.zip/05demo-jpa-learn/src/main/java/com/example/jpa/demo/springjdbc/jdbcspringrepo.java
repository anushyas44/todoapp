package com.example.jpa.demo.springjdbc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.jpa.demo.jpa.student.student;

@Repository
public class jdbcspringrepo {

	@Autowired
	private JdbcTemplate jdbctemp;

	private String INSERT_QUERY = """
					insert into student(id, name, address)
					values(1,'rajan','vadachennai');

					insert into student(id, name, address)
					values(2,'Dia','Vija');

					insert into student(id, name, address)
					values(3,'SK','karur');

					insert into student(id, name, address)
					values(4,'Sam','Chennai');

			""";

	private String SELECT_QUERY = """
				Select * from student;
			""";

	private String ins_query = """
			insert into student(id,name,address)
			values(?,?,?);
			""";
	
	private String delete_query = """
			delete from student where id=?;
			""";

	public void insert(student s) {
		jdbctemp.update(ins_query, s.getid(), s.getName(), s.getAddress());
	}

	public void insert1() {
		jdbctemp.update(INSERT_QUERY);

	}
	
	public void delete(int id) {
		jdbctemp.update(delete_query,id);
	}
	

	
}
	
