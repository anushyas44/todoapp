package com.example.jpa.demo.jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.jpa.demo.jpa.student.student;
import com.example.jpa.demo.jparepo.studentjpa;

@Component
public class cmdrun implements CommandLineRunner {

// 	for springJDBC
//	@Autowired
//	private jdbcspringrepo repo;

//	JPA method
//	@Autowired
//	private studentjpa repo;

	@Autowired
	private springdatajpa_ex repo;

	@Override
	public void run(String... args) throws Exception {

		// SPring Jdbc steps
//		repo.insert(new student(5, "Saravanan", "Karur"));
//		repo.insert(new student(2, "SK", "Chennai"));
//		repo.insert(new student(1, "Diana", "Vija"));
//		System.out.println("Insert query executed...");

//		repo.insert1();
//		
//		repo.delete(4);
//		System.out.println("delete query executed...");

		// JPA Method
//		repo.insert(new student(5, "Saravanan", "Karur"));
//		repo.insert(new student(2, "SK", "Chennai"));
//		repo.insert(new student(1, "Diana", "Vija"));
//		System.out.println("Insert query executed...");

//		repo.find(2);

//		repo.delete(5);
//		System.out.println("delete query executed...");

		// Spring Data JPA
		repo.save(new student(5, "Saravanan", "Karur"));
		repo.save(new student(2, "SK", "Chennai"));
		repo.save(new student(1, "Diana", "Vija"));
		System.out.println("Insert query executed...");

		repo.findById(2l);

		repo.deleteById(5l);
		System.out.println("delete query executed...");
		
		repo.save(new student(5, "Saravanan", "Karur"));
		System.out.println(repo.count());
	
	};

}
