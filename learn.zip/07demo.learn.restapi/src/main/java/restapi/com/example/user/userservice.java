package restapi.com.example.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class userservice {

	private userdbservice userab;

	@Autowired
	public userservice(userdbservice userab) {
		this.userab = userab;
	}

	@GetMapping("/users")
	public List<User> userlist() {
		return userab.findall();
	}

	@GetMapping("/users/{id}")
	public User userlist(@PathVariable int id) {
		return userab.findOne(id);
	}

//	@PostMapping("/users")
//	public void adduser(@RequestBody User user) {
//		userab.save(user);
//	}

	@PostMapping("/users")
	public ResponseEntity<User> adduser(@RequestBody User user) {
		userab.save(user);
		return ResponseEntity.created(null).build();
	}

	@DeleteMapping("/users/{id}")
	public void deleteuser(@PathVariable int id) {
		userab.delete(id);
	}

}