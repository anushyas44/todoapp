package restapi.com.example.user;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.springframework.stereotype.Component;

@Component
public class userdbservice {

	public static List<User> users = new ArrayList<>();

	static {
		users.add(new User(1, "Saravanan", LocalDate.now().minusWeeks(10)));
		users.add(new User(2, "Dia", LocalDate.now().minusYears(1)));
		users.add(new User(3, "SAM", LocalDate.now().minusYears(10)));
	}

	static int usercount = 3;

	public List<User> findall() {
		System.out.println(users);
		return users;
	}

	public User findOne(int id) {
		Predicate<? super User> predicate = user -> user.getId() == id;
		return users.stream().filter(predicate).findFirst().get();
	}

	public User save(User user) {
		user.setId(++usercount);
		users.add(user);
		return user;
	}

	public void delete(int id) {
		Predicate<? super User> predicate = user -> user.getId()==id;
		users.remove(id);
	}

}
