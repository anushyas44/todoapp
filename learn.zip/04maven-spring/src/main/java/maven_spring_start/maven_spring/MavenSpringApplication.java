package maven_spring_start.maven_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@SpringBootApplication
public class MavenSpringApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(MavenSpringApplication.class, args);
		
		System.out.println("Hellooo-_-_-o");
		
		
		
	}	

}