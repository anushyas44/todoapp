package maven_spring_start.maven_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
