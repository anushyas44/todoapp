package sample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

class student implements Comparable<student>{
	
	private int id;
	private String name;
	
	public student (int id, String name) {
		super();
		this.id = id;
		this.name = name;
		
		System.out.println(id +" "+name);
		
	}

	protected int getId() {
		return id;
	}

	protected void setId(int id) {
		this.id = id;
	}

	protected String getName() {
		return name;
	}

	protected void setName(String name) {
		this.name = name;
	}

	public String print() {
		return id+" "+name;
	}

	public int compareTo(student that) {
		return Integer.compare(this.id, this.id);
	}
		
}

public class collections {
	
	public static void main(String[] args) {
		
//student temp = new student(0, null);
		
		List<student> students = List.of(new student(100,"Sam"),
										 new student(110,"SK"),
										 new student(104,"Dani"));
		
		List<student> studentsAl = new ArrayList<>(students);
		System.out.println(students);
		
		Collections.sort(studentsAl);
		
		List<String> values = List.of("A","Z","C","A","G","X");
		System.out.println("List "+values);
		
		Set<String>	value1 = new TreeSet<>(values);
		System.out.println("Tres List "+value1);
	
		Set<String>	value2 = new LinkedHashSet<>(values);
		System.out.println("LinkHash List "+value2);
		
		Set<String>	value3 = new HashSet<>(values);
		System.out.println("Hash List "+value3);
	}
}
