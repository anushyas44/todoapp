package sample;


abstract class vechile{
	
	public abstract void model();
}

class bike extends vechile{

	public void model() {
	System.out.println("Yamaha");	
	}
}

class car extends vechile{
	public void model() {
		System.out.println("Swift");
	}
}
public class polymorphism {

	public static void main(String[] args) {

		vechile[] vec = {new car(), new bike()};
		for (vechile vechile:vec) {
			vechile.model();
		}
	}
}

