package sample;

import java.util.ArrayList;

class Mycustom<T>{
	
	ArrayList<T> list = new ArrayList<>();
	
	public void addelement(T element) {
		list.add(element);
	}
	
	public void removeelment(T element) {
		list.remove(element);
	}	
	
	public T getElement(int index) {
		return list.get(index);
		
	}
	public String toString() {
		return list.toString();
	}
}

public class genericexamples {
	
	public static void main(String[] args) {
		
		Mycustom<String> temp1 = new Mycustom<>();
		
		temp1.addelement("Element 1");
		temp1.addelement("Element 2");
		temp1.getElement(1);
		
		System.out.println(temp1.getElement(1));
		
		Mycustom<Integer> temp2 = new Mycustom<>();
		temp2.addelement(Integer.valueOf(5));
		temp2.addelement(Integer.valueOf(10));
		
		System.out.println(temp2);
	}

}
