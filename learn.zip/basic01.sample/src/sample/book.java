package sample;

import java.util.Scanner;

public class book {
	
	private int noOfcopies;
	public void  setNoOfcopies(int noOfCopies) {
			if (noOfCopies > 0) {
				this.noOfcopies = noOfCopies;
			}
			//return noOfCopies;
		}	
	
	public void noofcopiesincrease(int howmuch) {
		setNoOfcopies(this.noOfcopies+howmuch);
	}
	
	public void noofcopiesdecrease(int howmuch) {
		setNoOfcopies(this.noOfcopies+howmuch);
	}	

	
	
	public static void main(String[] args) {
		
//		book temp = new book();
//		temp.noofcopiesincrease(20);
//		System.out.println(temp.noOfcopies);
		
//		  for (int i=1;i<=5;i++) {
//			  System.out.println();
//			  for(int j=1;j<=i;j++) {
//				  System.out.print(j+" "); }
//		  }
		

		Scanner scan = new Scanner(System.in);
		System.out.println("enter the number :");
		int number =0;
		
	do { 
		number = scan.nextInt();
		System.out.println("cube value is "+number*number*number);
	}	
	while(number>0);
	System.out.println("bye");
		
	
		
	}

	}

