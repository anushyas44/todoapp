package sample;

public class primativedata {
	
public int countUppercaseLetters(String str) {
	        if(str == null){
	            return -1;
	        }
	        int count =0;
	        
	        for (int i =0; i<str.length(); i++){
	            if (Character.isUpperCase(str.charAt(i))){
	             count++;
	            }
	        }
	        return count;
	    }	

	public static void main(String[] args) {

		primativedata temp = new primativedata();
		System.out.println("count of upper "+temp.countUppercaseLetters("Hello WoRlD"));
		
		
		  for (int i=0; i<=100;i =i+1) {
	    	    if (i%4==0 && i%9==0){
	    	         System.out.println(i+" div /4 and 8");}
//	    	    if (i%5==0){
//	    	         System.out.println(i+" div /5");}
	       }
	    	
	
	
		float f =23.032f;
		double i =f;
		System.out.println(f);
			
		
	number sumnumber = new number();
	System.out.println(sumnumber.add(2,3));
	System.out.println(sumnumber.multiply(2, 10));
	System.out.println("double value is "+sumnumber.doublenumber(2, 10));
	
System.out.println(deterday(1));
	}
	
	public static String deterday(int i) {
		String result="";
		 
		switch(i) {
		case 0:return"Sunday";
		case 1://return"monday";
			break;
		case 2:return"tuesday";
		default:System.out.println("invalid");
		}
		
		return result;
	}
	

	

}	 
	       
	     
	    	    
	  
