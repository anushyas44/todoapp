package sample;

interface people{
	 int count =500;
	String dummy();
}

class man implements people{

	public String dummy() {
		// TODO Auto-generated method stub
		return ("Hello first method ");
	}
}


public class dummy {

	public static void main(String[] args) {
		man obj = new man();
		obj.dummy();
		System.out.println(obj.dummy());
		
	
	}
}
