package sample;

public class loops {
	
public int calculateFactorial(int number) {
        // Write your code here
        if(number <0){
        return -1;}
        
        int factorial =1;
        int noOftimes =0;
        for (int i = 2; i<=number; i++){
            factorial = factorial*i;
            noOftimes++;
        }
        return factorial;     
    }
    
public int getLastDigit(int number) {
        
        if (number ==0){
            return 0;
        }
        if (number <0){
            return -1;
        }
        return number % 10;  // to find last digit of number (% opeartion)
}

public int getNumberOfDigits(int number) {    
    if (number ==0){
        return 1;
    }
    if (number<0){
        return -1;
    }
    
    int noOfDiv =0;
    
    while (number >0){
        number = number /10;
        noOfDiv++;
    }
    return noOfDiv;
}

public int getSumOfDigits(int number) {
    if (number <0){
        return -1;
    } 
    
    if (number ==0){
        return 0;
}  
    int SumOfDigits =0;
    
    while(number >0){
        int digit= number%10; 
        SumOfDigits += digit;
        number = number /10;
        }
    return SumOfDigits;
  }

public int reverseNumber(int number) {
    if (number ==0){
        return 0;
    }
    if (number <0){
        return -1;
    }
     int reverseNumber =0;
     
     //System.out.println("number is "+number);
     
     while (number>0){  //9876
         int digit = number %10; //6
         reverseNumber = reverseNumber * 10 +digit; 
         number = number/10;
        System.out.println("digit "+digit+" reverseNumber "+reverseNumber+" number "+number);
     }
     return reverseNumber;   
 }


public static void main(String[] args) {
	
		loops temp = new loops();
		
		System.out.println("factorial "+temp.calculateFactorial(5));
		
		System.out.println("last digit "+temp.getLastDigit(35345734));
		
		System.out.println("no of digit "+temp.getNumberOfDigits(23456));
		
		System.out.println("sum of digit "+temp.getSumOfDigits(12345));
		
		System.out.println("sum of reverse no "+temp.reverseNumber(9876));
		
	
		String str = "hello world";
		System.out.println(str.equals(" bye world"));
	}
}
