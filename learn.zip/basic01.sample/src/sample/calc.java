package sample;


public class calc {


public static void main(String[] args) {
System.out.println("hey");
		
book temp = new book();
temp.noofcopiesdecrease(200);


}
