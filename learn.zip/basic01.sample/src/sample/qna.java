package sample;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.BufferedReader;

class A extends Thread{
	
	public static void dis() {
		for(int i=0;i<5;i=i+1) {
			System.out.println("Hey");
		}
	}
}

class B extends Thread{
	
	public void dis() {
		for(int i=0;i<5;i=i+1) {
			System.out.println("byee");	
		}
	}
}
public class qna {
	public static void main(String[] args) {

		A samp = new A();
		B dum = new B();
		
		samp.setPriority(2);
		
		Thread t1 = new Thread();
		t1.start();
		
		samp.start();
			
		dum.start();
	
	



//	try {
//	int age = scan.nextInt();
//	if (age<0) {
//		throw new NotvalidException("Your age is not valid");
//		}
//	}
//	
//	catch (NotvalidException e) {
//		System.out.println(e);
//	}
//	
//	catch (Exception e) {
//		System.out.println(e);
//	}
	
		
	System.out.println("Program endeddd ");
		
	}
}
