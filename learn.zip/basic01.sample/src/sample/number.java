package sample;

public class number extends Object{
	private int number1;
	private int number2;
	
	int num3;
	int num4;
	
	int add(int number1, int number2) {
		this.number1=number1;
		this.number1=number2;
		return number1+number2;		
	}

	int multiply(int number1, int number2) {
		this.number1=number1;
		this.number1=number2;
		return number1*number2;		
	}

	public int doublenumber(int number1, int number2) {
		return number1*=2;
		
		
	}

}
