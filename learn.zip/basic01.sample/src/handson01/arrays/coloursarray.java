package handson01.arrays;

import java.util.ArrayList;
import java.util.List;

public class coloursarray {

	public static void main(String[] args) {
		
		List<String> colour = new ArrayList<String>();
		colour.add("Black");
		colour.add("Red");
		colour.add("Green");
		colour.add("yellow");
		
		System.out.println(colour);

// ex 2-------------------------------		
		for(String Colour:colour) {
			System.out.println(Colour);
		}
		
// ex 3-------------------------------	
				
	}
}
