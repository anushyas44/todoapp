package collection_d;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;


public class concur_ex extends Thread {
	
	static ConcurrentHashMap<Integer, String> c = new ConcurrentHashMap();
	
	Thread t1 = new Thread();
	
	public void run() {
		for (int i=0; i<=4; i++) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			c.put((Integer)i, "AAA");
			System.out.println(c);
		}
	
	}

	public static void main(String[] args) throws Exception{
		
		c.put((Integer)102, "BBB");
		c.put((Integer)103, "CCC");
	
		concur_ex c1 = new concur_ex();
		c1.start();
	
		
		Set s = c.keySet();
		Iterator it = s.iterator();
		
//		for (Map.Entry<Integer, String> entry : c.entrySet()) {
//			System.out.println(entry.getKey()+"......"+entry.getValue());
//		}
		
		while(it.hasNext()) {
			System.out.println("keys..."+c.keySet()+"/"+"values..."+c.values());
			System.out.println(it.next());
			Thread.sleep(100);
		}
		
		System.out.println("full hahmap is"+s);
		

	}


}
