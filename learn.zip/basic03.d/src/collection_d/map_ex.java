package collection_d;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class map_ex {
	
	public static void main(String[] args) {
		
		HashMap<Integer, String> m = new HashMap<>();
		
		m.put(1, "Sarvan");
		m.put(2, "Bsarvan");
		m.put(3, "Csarvan");
		m.put(1, "SK");
		
/*		for(Map.Entry<Integer, String> Entry : m.entrySet()) {
			
			System.out.println(Entry.getKey()+"....."+Entry.getValue());
				
			if(Entry.getKey().equals(3)) {
				Entry.setValue("DDD");				
			}				
		}
*/
	
		Collection c = m.entrySet();
		Iterator it = c.iterator();
		
		while(it.hasNext()) {
			
			Map.Entry entry = (Map.Entry)it.next();
			
			System.out.println(entry.getKey()+"...."+entry.getValue());
			
			if(entry.getKey().equals(3)) {
				entry.setValue("ZZZZZ");
			}
		}
		

		System.out.println(m);
//		System.out.println(m.isEmpty());
//		System.out.println(m.entrySet());
		System.out.println(m.size());
//		System.out.println(m.values());
//		System.out.println(m.keySet());
//		System.out.println(m.replace(3, "ZSARAa"));
//		System.out.println(m);
	}

}
