package collection_d;

import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

public class hash_table_ex {

	public static void main(String[] args) {
		
		Hashtable ht = new Hashtable(11);
	
//		ht.put(new cls(5), "AAA");
//		ht.put(new cls(2), "BBB");
//		ht.put(new cls(6), "CCC");
//		ht.put(new cls(15), "DDD");
//		ht.put(new cls(23), "EEE");
//		ht.put(new cls(16), "FFF");
		
		ht.put(5, "AAA");
		ht.put(2, "BBB");
		ht.put(6, "CCC");
		ht.put(15, "DDD");
		ht.put(23, "EEE");
		ht.put(16, "FFF");
		
		
		for (Object key : ht.keySet()){
		System.out.println(key.hashCode() % 11+"\t"+key+"\t"+ht.get(key));
		}
		
		System.out.println(ht);
		
		System.out.println(ht.hashCode());
		//402204
	
		
	}
}
class cls{
	
	int i;
	cls(int i){
		this.i=i;
	}
	
//	public int hashCode(){
//
//		return i;
//	}
	
	public String toString() {
		return ""+i;
	}
}

