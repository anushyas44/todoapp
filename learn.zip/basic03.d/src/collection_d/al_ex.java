package collection_d;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class al_ex {

	public static void main(String[] args) {
		
		ArrayList x = new ArrayList();
		

		
		x.add(10);
//		x.add("dummy");
//		x.add("apple");
		x.add(200);
		x.add(5);
		x.add(999);
		
		
		System.out.println(x);
		x.remove(1);
		System.out.println(x);
		x.add(3,"104");
		System.out.println(x);
		System.out.println(x.add("301"));
		
		System.out.println(x.size());
		
		List l1 = Collections.synchronizedList(x);
	
		Collections.sort(x);;
	
		
	}

}
