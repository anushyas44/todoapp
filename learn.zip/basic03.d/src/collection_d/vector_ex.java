package collection_d;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
import java.util.Vector;

public class vector_ex {

	public static void main(String[] args) {
		
		Vector x = new Vector();
		
		for(int i = 0; i<=10; i++) {
			x.add(i);
		}
	
		
		x.add(10);
		x.add("dummy");
		x.add("apple");
		x.add('x');
		
		System.out.println(x);
		x.remove(1);
		System.out.println(x);
		x.add(3,"BUS");
		System.out.println(x);
		
		System.out.println(x.capacity());
		
//		List l1 = Collections.synchronizedList(x);
		
//		System.out.println(l1);
				
		Stack s = new Stack();
		s.push(100);
		s.push("Samm");
		s.push('C');
		
		System.out.println(s);
		System.out.println(s.search(100));
		
		while(!s.isEmpty()) {
			System.out.println(s.pop());
		}
		
		System.out.println(s);
		
		Iterator i =s.iterator();
		
		while(i.hasNext()) {
			System.out.println(i);
		}
	}

}
