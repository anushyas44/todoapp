package collection_d;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class hash_ex {

	public static void main(String[] args) {
		
		Set s = new TreeSet();
		
		HashSet<Object> h = new HashSet();
		
		h.add("Apple");
		h.add(2);
		h.add('C');
		h.add(2);
		h.add('A');
		h.add("BB");
		h.add(null);
		
		System.out.println(h);
		System.out.println(h.add(2));
		
		Iterator it = h.iterator();
		

		SortedSet<Object> i = new TreeSet();
		
		i.add("Apple");
		i.add("BUs");
		i.add("CAT");
		i.add("");
		i.add("BB");
		
		System.out.println("**********Tree set*********");
		System.out.println(i);
	
		System.out.println(i.first());
		System.out.println(i.last());
		
		System.out.println("D".compareTo("A"));
		
		
	}
	
}
