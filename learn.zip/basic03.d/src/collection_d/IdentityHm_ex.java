package collection_d;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.WeakHashMap;

public class IdentityHm_ex {

	public static void main(String[] args) {
	
		HashMap hm = new HashMap();
		
		Integer i1 = new Integer(100);
		Integer i2 = new Integer(100);
		
		hm.put(i1, "AAA");
		hm.put(i2, "BBB");
		
		System.out.println(hm);
		
		IdentityHashMap<Integer, String> ihm = new IdentityHashMap<Integer, String>();
		
		Integer i3 = new Integer(100);
		Integer i4 = new Integer(100);
		
		ihm.put(i3, "AAA");
		ihm.put(i4, "BBB");
		
		System.out.println("**********== Comparision*********");
		
		System.out.println(ihm);
		
		System.out.println("***comparison between hashmap and weak hashmap");
		temp t = new temp();
		
//		hm.put(t, "SARAVANNNN");
//		t = null;
//		System.gc();
//		System.out.println(hm);
		
		WeakHashMap whm = new WeakHashMap();
		whm.put(t, "SARAVANNNN");
		t = null;
		System.gc();
		
		System.out.println(whm);
		
	}

}

class temp{
	
	public String toString() {
		return "Temppp";
	}
	
	public void finalize() {
		System.out.println("Object removed by GC");
		System.out.println("Finalize() called...");
	}
}