package collection_d;

import java.util.Comparator;
import java.util.TreeSet;

class custom implements Comparator{

	public int compare(Object n1, Object n2) {
		Integer i1 = (Integer)n1;
		Integer i2 = (Integer)n2;
	
		if(i1 > i2) {
			return -1;
		}
		else if(i1 < i2) {
			return +1;
		}
		else
		return 0;
	}
}

class custom1 implements Comparator{

	public int compare(Object n1, Object n2) {
		StringBuffer i1 = (StringBuffer)n1;
		StringBuffer i2 = (StringBuffer)n2;
	
		return -i1.compareTo(i2);
	}	

}


public class tree_s {

	public static void main(String[] args) {
		
		TreeSet t = new TreeSet(new custom1());
		
//		t.add(10);
//		t.add(5);
//		t.add(8);
//		t.add(20);
//		t.add(0);
//		t.add(23);
//		t.add(21);
//		t.add(23);
		
//		t.add("ASaravanan");
//		t.add("CSara");
//		t.add("BBB");
//		t.add("ISara");
//		t.add("ZSara");
		
		t.add(new StringBuffer("ASaravanan"));
		t.add(new StringBuffer("CSara"));
		t.add(new StringBuffer("BBB"));
		t.add(new StringBuffer("ISara"));
		t.add(new StringBuffer("ZSara"));
		
		Object c = new String("BBB");
				
		System.out.println(t);
		System.out.println(t.toString());
		
		custom1 d = new custom1();
		
		
		System.out.println(t);

		
	}
	
}
