package collection_d;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

public class priority_que_ex {

	public static void main(String[] args) {
		
		Queue q = new PriorityQueue(new cutom());
		
		q.add(100);
		q.offer(2);
		q.offer(30);
		q.offer(30);
		q.offer(40);
		System.out.println(q.offer(5000));
		
		System.out.println(q);
		q.poll();
		System.out.println(q);
		System.out.println(q.poll());
		System.out.println(q);
		
	}

}
class cutom implements Comparator{

	public int compare(Object o1, Object o2) {
		Integer i1 = (Integer)o1;
		Integer i2 =(Integer)o2;
		
		return i2.compareTo(i1);
	
	}
	
}