package collection_d;

import java.util.ArrayDeque;
import java.util.PriorityQueue;

public class que_ex {

	public static void main(String[] args) {
		
		PriorityQueue pd = new PriorityQueue();
		pd.add(100);
		pd.offer(200);
		pd.add(400);
		
		System.out.println(pd);

		
		ArrayDeque ad = new ArrayDeque();
		ad.add(pd);
		ad.addFirst("AAA");
		ad.addLast("ZZZ");
		
		System.out.println(ad);
	}

}
