package collection_d;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class hashmap_ex {

	public static void main(String[] args) {
		
		String s = new String("java is fun and java is powerful");
		
		String s1 = s.toLowerCase();
		String[] s2 = s1.split(" ");
				
		Map<Integer, String> m = new HashMap();
		m.put(1, "AAAAAA");
		m.put(5,"BBBB");
		m.put(3, "CCCC");
		m.put(4, "DDDDDD");
		
		int i=1;

		for(Map.Entry<Integer, String> entry : m.entrySet()) {
			System.out.println("Value "+i+" : "+entry.getValue());
			i++;
		}
				
		for(Entry<Integer, String> val : m.entrySet()) {
			System.out.println(val.getKey());
			
			if(val.getKey() == 4) {
				System.out.println( val.setValue("EEEE"));
			}
		}
		
		
		System.out.println(m);	
		
	}
	
	
}
