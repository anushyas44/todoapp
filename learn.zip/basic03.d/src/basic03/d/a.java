package basic03.d;

class parent {
	
	static int x = 100;
	{
		System.out.println("Intial s value :");
	}
	{
		System.out.println(x);
		System.out.println("parent instance method");
	}
	parent(){
		System.out.println("Parenet constr");
		m1("BBB");
	}
	static String s = "AAA";

	public String m1 (String s) {
		System.out.println("Value of s :"+s);
		return s;
	}	
	public static int m2(int x) {
		System.out.println("Static met "+x);
		return x;
	}
}
class a extends parent{
	static int y = 200;
	public static void main(String[] args) {
		System.out.println("Main method");
		
		parent p = new parent();
		System.out.println(p.s);
		p.m2(333);
		System.out.println(a.x);		
	}
	public static void methodone() {
		System.out.println("method one -" +y);
	}
	static int i=2;
}