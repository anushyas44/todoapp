package basic03.d;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class communi_thread extends Thread{
	public static void main(String[] args) throws InterruptedException {
		B b = new B();
		b.start();
		synchronized (b){
			b.wait();
			System.out.println(b.count);		
		}
		System.out.println(Thread.currentThread().getThreadGroup().getName());
	
		ThreadGroup t1 = new ThreadGroup("sample");
		Thread r1 = new Thread(t1, "first");
		t1.setMaxPriority(4);
		Thread r2 = new Thread(t1,"second");
		
		System.out.println(r1.getPriority());
		System.out.println(r2.getPriority());
		
		ThreadGroup g = Thread.currentThread().getThreadGroup().getParent();
		Thread[] t = new Thread[g.activeCount()];
		g.enumerate(t);
		for (Thread thr:t) {
			System.out.println(thr.getName()+" is name "+thr.isDaemon());
		}
		
		ReentrantLock l = new ReentrantLock();
		l.lock();
		System.out.println(l.isLocked());
		System.out.println(l.getQueueLength());
		System.out.println(l.isHeldByCurrentThread());
	}
}
class B extends communi_thread{
	
	int count = 0;
	public void run() {
		
		synchronized (this) {		
		for(int i=0;i<=100;i++) {
			count= count+i;
		}
		this.notifyAll();	
		}
	}
}

