package basic03.d;

public class acsmodifiers {
	
	protected void m1() {
		System.out.println("protected modifiers");
	}

}

class A extends acsmodifiers{
	
public static void main(String [] args) {
	
	acsmodifiers B = new acsmodifiers();
	B.m1();
	
	acsmodifiers A = new acsmodifiers();
	A.m1();
	
}	
}
