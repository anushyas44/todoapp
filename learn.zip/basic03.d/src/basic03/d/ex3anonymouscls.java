package basic03.d;

class car{
	
	String colour() {
		System.out.println("Black");
		return "Black";
	}
	
	int price() {
		System.out.println(10000);
		return 10000;
	}
}

public class ex3anonymouscls {
	

	public static void main(String[] args) {
	
		car c1 = new car() {
			String colour() {
				System.out.println("White..");
				return "White";
			}
		};
		
		c1.colour();
		c1.price();
		
		car c = new car();
		System.out.println(c.getClass().getName());
		System.out.println(c1.getClass().getName());
		
		Thread t = new Thread() {
			public void run() {
				for (int i=1; i<5; i++) {
					System.out.println("mainnnn");
				}
			}
		};
		t.start();
		
	}

}
