package basic03.d;

import java.util.concurrent.locks.ReentrantLock;

class disply{
	
	public synchronized void print(String name)  {
		
		ReentrantLock lock = new ReentrantLock();
		lock.lock();
		
		for(int i=0;i<=5;i++) {
			System.out.println("Hello : ");
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.print(name);
		}
		lock.unlock();
	}
}

class dummy extends Thread {
	
	disply d;
	String name;
	
	dummy(disply d, String name){
		this.d=d;
		this.name=name;
	}
	public void run() {
			d.print(name);
				
	}
}
public class threadex {
	
public static void main(String[] args) {
	
	disply d1 = new disply();
	dummy t = new dummy(d1, "sk");
	dummy t2 = new dummy(d1, "sarvaanan");
	t.start();
	t2.start();
	
}

}