package basic03.d;


public class basicfundamental {
	

static void m1(int... x) {
		
		int total = 0;
		for (int a:x) {
			total = total+a;
		}
		System.out.println(total);
	}

public static void main(String[] args) {
	
	
		int s1 =3; 
		String str = "Hello";
		long b;
		byte c;
		
		long d = -124 * 123;
		
		char f = 'த';
		int g = 010;
		int h = 0X10;
		double i = 0123.456;
		int ch =654232;
		
		System.out.println(s1 +" "+" " +str);
		System.out.println(h);
		System.out.println(s1+g+h);
		
//----------------------------

		int[][] x = new int[2][];
		x[0] = new int[2];
		x[1] = new int [3];
		
		x[0][0] = 23;
		x[1][2] = 1;
		x[1][0] = 23;
		
		Number[] y = new Number[2];
		Class[] z = new Class[3];
		
		int[] x1 = new int[2];
		x1[0]= 1;

		for (int k=0; i<args.length;i++) {
			System.out.println("Numbers "+x1[k]);
		}
		
		String[] s = {"Ab","Ba","Cc"};
		
		for(String dummy:s) {
			System.out.println(dummy);
			
		}
//-----------------------
		
		
		System.out.println(z);
		System.out.println(x[1][1]);
		System.out.println(x[0][1]);
		System.out.println(x[1].length);
		
//------------------------------
//	local variable	
		int aa;
		if (g>0) {
			aa=12;
		}else {
			aa=0;
		}
		System.out.println(aa);
		
basicfundamental bf = new basicfundamental();
bf.m1(2);
bf.m1(2,4,3,4);



		
}
		
}