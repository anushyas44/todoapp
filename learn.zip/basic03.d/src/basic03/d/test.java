package basic03.d;

import java.text.DateFormat;

//class x{
//	
//	String a = "Sam";
//	int b = 1000;
//	protected x(){	
//	}
//}

public class test{
//	String a;
//	int b;
//	
//	test (String a, int b){
//	this.a=a;
//	}
//	
//	void m1(){
//		System.out.println(this.a);
//		m2();
//	}
//	
//	void m2() {
//		DateFormat df =DateFormat.getDateTimeInstance();
//		System.out.println(df);
//	}
	public static void main(String[] args) throws ArithmeticException{
//		test t = new test("sk",25);
//		t.m1();
//		System.out.println(t.a);
		
		domore();
		System.out.println("Hellooo");
		
	}

	private static void domore() throws ArithmeticException {
		domore2();
	}

	private static void domore2() throws ArithmeticException{
		
//		Thread.sleep(1000);
		System.out.println(10);
	}
	
}
