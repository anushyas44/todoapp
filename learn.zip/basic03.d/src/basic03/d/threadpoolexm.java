package basic03.d;

import java.lang.reflect.Method;

class customerThread extends Thread{
//	static int custid=0;
//		ThreadLocal t1 = new ThreadLocal() {
//		protected  Object  initialValue()
//		{
//			return ++custid;
//		}
//	};
	
	InheritableThreadLocal t1 = new InheritableThreadLocal();
	
	String name;
	customerThread(String name){
		this.name = name;
	}
	
	public void run() {
		
		t1.set("name - abc");
		System.out.println(Thread.currentThread().getName()+" excuted by "+name+" unique id = "+t1.get());
		
		childthread c1 = new childthread();
		c1.start();	
	
}
	


class childthread extends Thread{
	

	public void run() {
		System.out.println("child thread "+t1.get());
	}
	
	
}
}
	
public class threadpoolexm {

	public static void main(String[] args) throws ClassNotFoundException {	
		

		customerThread th1 = new customerThread("customer 1");
		customerThread th2 = new customerThread("customer 2");
		customerThread th3 = new customerThread("customer 3");
		customerThread th4 = new customerThread("customer 4");
		
//		th1.start();
//		th2.start();
//		th3.start();
//		th4.start();

		int count =1;
		
		Class c = Class.forName("java.lang.Object");
		Method [] m = c.getDeclaredMethods();
				for (Method m1:m) {
				
					System.out.println(count+m1.getName());
					count++;
		}
	
		
		
		
	}

}
