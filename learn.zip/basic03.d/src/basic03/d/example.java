package basic03.d;

import java.util.Scanner;


public class example {
	
public static void main (String[] args) {
		System.out.println("Main class");
		
int x =10;

switch (x) {

case 97:
	System.out.println("97");
	break;

case 98:
	System.out.println(75);
	break;

case 'c':
	System.out.println(98);
	break;
	
default: System.out.println("not found");	
	}


int y= 05;
while (x >=y) {
	System.out.println("hellooo");
	y++;
}

int [] x1 = {10,20,30};

for (int x2:x1) {
	System.out.println(x2);
}

int[][] y1 = {{100,200,300},{400,500}};

for (int[] y2:y1) {
	for (int y3:y2) {
		System.out.print(y3+",");
	}
}
System.out.println();

int [][][] z1 = {{{100,200,300},{400,500},{600,700,800,900}}};

for (int[][] z2:z1) {
	for (int[] z3:z2) {
		for (int z4:z3) {
			System.out.print(z4+";");
		}
	}
}


//for (int i=0; i<=10; i++) {
//	
//	if(i==6) break;
//	System.out.println(i);
//	
//}

}
}

//class temp extends example{
//	
//	public static void main (String[] args) {
//		System.out.println("Child class");
//	}
//	
//}
