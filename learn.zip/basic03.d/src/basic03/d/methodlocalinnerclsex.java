package basic03.d;

public class methodlocalinnerclsex {
	
	int a = 10;
	static String c ="ABA";
	
	 void m1() {
		
		int b = 20;
		final char d ='c';
		System.out.println("heloooo");
		
		 class inner {
			
			public static void sum(){
								
				//System.out.println(a);
				//System.out.println(b);
				System.out.println(c);
				System.out.println(d);				
				}
		}
			inner in = new inner();
			in.sum();

	}

	public static void main(String[] args) {

		new methodlocalinnerclsex().m1();		
	}

}
