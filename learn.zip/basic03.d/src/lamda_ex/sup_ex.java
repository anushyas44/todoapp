package lamda_ex;

import java.util.function.Supplier;

public class sup_ex {

	public static void main(String[] args) {
		
		Supplier<String> s = () ->{
			
			String otp ="";
			for(int i=0; i<=4;i++) {
				otp = otp+(int)(Math.random()*10);
			
			}
			
			return otp;	
			
		};
		
		System.out.println("Otp value is : "+s.get());

		
	}
	
	public static boolean m1(Integer a, Integer b) {
		return (a+b)%2==0;
		
	}

}
