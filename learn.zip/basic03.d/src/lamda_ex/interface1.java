package lamda_ex;


public interface interface1 {
	public static void Main(String[] args) {
		System.out.println("Hello from interface");
	}

}

interface x{

}
