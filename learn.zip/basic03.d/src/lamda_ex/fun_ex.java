package lamda_ex;

import java.util.function.Function;

public class fun_ex {

	public static void main(String[] args) {


		Function<String,Integer> f = s->s.length();
		System.out.println(f.apply("SAravanakumar_m"));
		
		Function<String,String> f2 = s2->s2.replaceAll(" ", "");
		System.out.println(f2.apply("S A R A  V Annn"));
		
		Function<String,Integer> f3 = s2->s2.length() - s2.replaceAll(" ", "").length();
		System.out.println(f3.apply("S A R A V Annn"));
		
		
	}

}
