package lamda_ex;

public class thread_ex {

	public static void main(String[] args) {
		
		Runnable r = ()-> {
			for (int i=0; i<=10; i++) {
				System.out.println("2nd thread excuted  : "+i);
			}
		};
		Thread t = new Thread(r);
		t.start();
		
		for (int i=10; i<=20; i++) {
			System.out.println("Main thread done : "+i);
		}

	}

}
