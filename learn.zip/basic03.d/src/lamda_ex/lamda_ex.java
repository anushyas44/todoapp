package lamda_ex;

import java.util.ArrayList;
import java.util.Collections;

interface inter{
	
	public int add(int a, int b);
}

public class lamda_ex {

	public static void main(String[] args) {
		
		
		inter Y = (a,b) ->{
		
			 System.out.println("Hello : "+(a+b));
			 return a+b;
			
		};
		
		Y.add(10, 20);
		
		Runnable t = () ->{
			for (int i=0; i<=10 ; i++) {
				System.out.println("dummy ... "+i);
			}
		};
//-------------------------------------------------
		
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(100);
		al.add(25);
		al.add(10);
		al.add(200);
		al.add(99);
		
		System.out.println("Original list : "+al);
		//Collections.sort(al);
		//System.out.println("Sorted list : "+al);
		
		Collections.sort(al,(l1,l2)->(l1>l2)?-1:(l1>l2)?1:0);
		
	
		
		System.out.println(" desen Sorted list : "+al);

	}

}
