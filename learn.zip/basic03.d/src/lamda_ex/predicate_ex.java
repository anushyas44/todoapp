package lamda_ex;

import java.util.function.Predicate;

public class predicate_ex {

	public static void main(String[] args) {
		

		
		
		Predicate<String> pr = i-> i.length()>4;
		
		System.out.println(pr.test("AAAAA"));
		
		int[] a = {5,10,15,20,25,30,40,45};
		
		Predicate<Integer> p1 = i -> i>10;
		Predicate<Integer> p2 = i -> i%2==0;
		
		
		//m1(p1, a);
		//m1(p2, a);
		//m1(p1.negate(),a);		
		//m1(p1.and(p2),a);
		m1(p1.or(p2),a);
		
		
	}
	
	public  static void m1(Predicate<Integer> p, int[] a) {
		for(int x:a) {
			if(p.test(x)) {
				System.out.println(x);
			}
		}
		
	}

	

}
