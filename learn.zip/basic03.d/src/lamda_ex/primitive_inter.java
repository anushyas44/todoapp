package lamda_ex;

import java.util.function.IntPredicate;
import java.util.function.UnaryOperator;

public class primitive_inter {

	public static void main(String[] args) {
		
		Integer i = Integer.valueOf(10);
		Integer j = Integer.valueOf(20);
		
		int a = 199;
		int b = 300;
		
		System.out.println(m1(i, j));
		
		IntPredicate p = s -> s%2==0;
		
		System.out.println(p.test(a));
		
//****Unary Operator
		
		UnaryOperator<Integer> s = x->++x;
		System.out.println(s.apply(20));
		System.out.println();
		
	}

	private static Boolean m1(Integer i, Integer j) {
	
		return (i+j)%2==0;
	}

}
