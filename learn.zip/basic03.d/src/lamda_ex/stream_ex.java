package lamda_ex;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class stream_ex {

	public static void main(String[] args) {
		
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(10); al.add(20); al.add(30);
		al.add(15); al.add(25); al.add(35);
		
		System.out.println(al);
		
		List<Integer> al2 = al.stream().filter(s->s%2==0).collect(Collectors.toList());
		
		System.out.println(al2);
		
//date and month...............
		
		LocalDate date = LocalDate.now();
		System.out.println(date);
		
		int dd = date.getDayOfMonth();
		int mm = date.getMonthValue();
		int yyy = date.getYear();
		int y = date.getDayOfYear();
		
		System.out.printf("%d-%d-%d-%d",dd,mm,yyy,y);
		System.out.println();
		System.out.println(y);

		
	}

	
}
