package jvm;

import java.lang.reflect.Method;

class test extends ClassLoader{
	
}

public class loading_ex {

	public static void main(String[] args) throws ClassNotFoundException {
		
		int count =0;
		
		Class<?> t = Class.forName("java.util.Collection");
		Method[] m = t.getDeclaredMethods();
		
		for(Method m1 :m) {
			System.out.println(m1);
			count++;
		}
		
		System.out.println("Total methods : "+count);
		
		System.out.println(Object.class.getClassLoader());
		System.out.println(loading_ex.class.getClassLoader());
		
	}

}
