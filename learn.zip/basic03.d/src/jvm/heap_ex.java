package jvm;

import java.util.ArrayList;

public class heap_ex {
	
    record man(int x,int y) {
    	
    }

	public static void main(String[] args) {
		
		double mb = 1024*1024;
		System.out.println(mb);
		
		Runtime r = Runtime.getRuntime();
		System.out.println((r.maxMemory()/mb)/1024);
		
		
        System.out.println("Size of int: " + Integer.BYTES + " bytes");
        System.out.println("Size of short: " + Short.BYTES + " bytes");
        System.out.println("Size of long: " + Long.BYTES + " bytes");
        System.out.println("Size of int: " + Float.BYTES + " bytes");
        System.out.println("Size of short: " + Double.BYTES + " bytes");
        
        ArrayList<Integer> a = new ArrayList<>();
        var b = 10;
        var c = 20;
        var d = 30;
        a.add(b);
        a.add(c);
        a.add(c);
        
        var z = "Sarva";
        
        System.out.println(z.repeat(10));
        
        System.out.println(a);


      man m = new man(10, 20);
      
      System.out.println(m);
      
      
        
	}

}
