package D_obj;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class files_d {

	public static void main(String[] args) throws Exception {
		
		int count =0;
		File f = new File("C:\\Users\\2209080\\downloads");
		
		String [] b = f.list();
		
		for (String b1:b) {
			count ++;
			//System.out.println(b1);			
		}
		System.out.println("total "+count);
		


        try {
            PrintWriter writer = new PrintWriter("output.txt");
            writer.println("Hello, world!");
            writer.println("This is written using PrintWriter.");
            writer.printf("Formatted number: %.2f%n", 123.456);
            writer.close();
            System.out.println("Data written to output.txt");
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());

        }

	}

}
