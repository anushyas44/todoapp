package D_obj;


class test{	
	
	Integer i = 10;
	
}
public class lang_autobox {
	
	public static void m1 (Integer i) {
		System.out.println("Int method ran");
	}
	
	public static void m1(long i) {
		System.out.println("Widening method");
	}

	public static void main(String[] args) {
		
		int x = 10;
		
		m1(x);
		
	}

}
