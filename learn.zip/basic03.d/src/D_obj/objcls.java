package D_obj;

class Test{
	int i;

	Test(int i){
		this.i = i;
	}
	
	public int hashCode() {
		return i;		
	}
	
	public String toString() {
		return i+" Test"+hashCode();
	}
	
	 public void m1() {
		 
	 }
}

public class objcls {

	public static void main(String[] args) {
		
		Test t = new Test(10);
		Test t1 = new Test(200);
		
		System.out.println(t.toString());
		System.out.println(t1.toString());
		
		int [] a = {10,20};
//		a[1] = 20;
//		a[2]=30;
		

		
		System.out.println(a[2]);
	}

}
