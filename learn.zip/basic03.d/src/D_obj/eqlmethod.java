package D_obj;

class man{
	
	String name;
	int num;
	
	man(String name, int num){
		this.name=name;
		this.num=num;
		}
	

	public boolean equals(Object obj) {
		
	try {
		String name1 = this.name;		
		int num1 = this.num;
			
		man m = (man)obj;
		String name2 = m.name;
		int num2 = m.num;
		
		if (name1.equals(name1) && num1 == num2) {
			return true;
		}
		
	} catch (Exception e) {
		
	};
	return false;
		
	}
	
/*	
	public boolean equals(Object obj) {
		man m = (man)obj;
		
		if (name.equals(m.name) && num == m.num) {
			return true;
		}
		else {
			return false;
		}
	}
	
*/
}

public class eqlmethod {

	public static void main(String[] args) {
		String s = "java";
		
		man m1 = new man("saravanan", 23);
		man m2 = new man("diana", 22);
		man m3 = new man("saravanan", 23);
		
		System.out.println(m1.equals(m2));
		System.out.println(m1.equals(m1));
		System.out.println(m1.equals(m3));
		
		System.out.println(m1.getClass().getName());

		System.out.println(s.charAt(1));
		System.out.println(s.equals("Java"));
		System.out.println(s.equalsIgnoreCase("Java"));
		
		StringBuffer sb = new StringBuffer();
		sb.append("abf");
		StringBuffer sb2 = new StringBuffer(s);
		System.out.println(sb.capacity());
		System.out.println(sb2.capacity());
		
		int x = 10;
		int y=x;
		++x;
		
		System.out.println(x);
		System.out.println(y);
		System.out.println(x==y);
		
		System.out.println(s.concat(" world"));
	}

}
