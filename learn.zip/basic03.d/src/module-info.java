/**
 * 
 */
/**
 * 
 */
module basic03.d {
}