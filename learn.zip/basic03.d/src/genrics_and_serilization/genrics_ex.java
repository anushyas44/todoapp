package genrics_and_serilization;

import java.util.ArrayList;

class test{
	
	
	void dummy() {
		System.out.println("Method called by using parent refer");
	}
	
}

class t1 extends test{
	void ex() {
		System.out.println("Method called by using parent refer .......t1");
	}
	
}

public class genrics_ex {

	public static void main(String[] args) {
		
		 test Test = new t1();
		 t1 T1 = new t1();
		 Test.dummy();
		 T1.ex();
		 
		 ArrayList<String> al = new ArrayList<String>();
		 al.add("AAA");
		 al.add((String)"BBB");
		 
	}

}
