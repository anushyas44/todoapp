package genrics_and_serilization;

import java.util.Date;

public class gc_ex {

	public static void main(String[] args) {
		Runtime r = Runtime.getRuntime();
		
		System.out.println(r);
		System.out.println("Total mem : "+r.totalMemory());
		System.out.println("Free mem : "+r.freeMemory());
		System.out.println("used memory : "+(r.totalMemory()-r.freeMemory()));
		
		for(int i=0; i<=10000; i++) {
			Date d = new Date();
			d=null;
		}
		r.gc();
		
		System.out.println("Free memory : "+r.freeMemory());


	}
	public void finalize() {
		
	}

}
