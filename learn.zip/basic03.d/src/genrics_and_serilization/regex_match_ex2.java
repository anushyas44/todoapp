package genrics_and_serilization;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class regex_match_ex2 {
	
	enum num{
		One, Two, Three;
	}

	public static void main(String[] args) {
		
		Pattern p = Pattern.compile("(0/91)?[7-9][0-9]{9}");	
		
		String input = "9626051884";
		Matcher m = p.matcher("9626051884");
		
		if(m.matches()) {
			System.out.println("Valid mob number...");
		} 
		else {
		System.out.println("...");
		}
		
		Locale l = Locale.CHINA;
		System.out.println(l.getDefault());
		System.out.println(l.getDisplayCountry());
		
		num[] n = num.values();
		
		for(num n2 :n) {
			System.out.println(n2+".. ... ..."+n2.ordinal());
		}
		
	}

}
