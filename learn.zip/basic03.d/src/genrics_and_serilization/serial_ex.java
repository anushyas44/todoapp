package genrics_and_serilization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class dog implements Serializable{
	
	transient int i = 100;
	transient char c = 'A';
	
}
public class serial_ex {

	public static void main(String[] args) {
			dog t = new dog();
		
		try {
			FileOutputStream f1 = new FileOutputStream("abc.text");
			ObjectOutputStream o = new ObjectOutputStream(f1);
			o.writeObject(t);
			o.writeObject(t);
			
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Serialization is completed");
		
		Object obj;
		
		try {
			FileInputStream f2 = new FileInputStream("abc.text");
			ObjectInputStream o2 = new ObjectInputStream(f2);
			obj = o2.readObject();
//			System.out.println("Obj value is : "+obj.i);
//			System.out.println("Obj value is : "+obj.c);
			if(obj instanceof dog) {
				dog d2 = (dog)obj;
				System.out.println("Obj value is : "+d2.c);
				System.out.println("Obj value is : "+d2.i);
			}
			
			
		}	catch(Exception e) {
			System.out.println(e);
		}
		System.out.println("De-serialization is completed..");
		
	}

}
