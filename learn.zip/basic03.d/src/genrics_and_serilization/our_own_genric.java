package genrics_and_serilization;

import java.util.ArrayList;
import java.util.LinkedList;

class account1<T>{
	
	T obj;
	account1(T obj){
		this.obj = obj;
	}
	
	void name(){
		System.out.println("account name is ..."+obj.getClass().getName());
	}
	
	public T get(){
		return obj;	
	}
	
}
public class our_own_genric {

	public static void main(String[] args) {
		
		account1<String> ac = new account1<String>("Gold level");
		ac.name();
		System.out.println(ac.get());
		
		account1<Float> ac1 = new account1<Float>(10.0F);
		ac1.name();
		System.out.println(ac1.get());
		
		LinkedList l = new LinkedList();
		l.add("AAA");
		l.add("BBB");
		l.add("CCC");
		
		ArrayList<String> l3=new ArrayList<>();
		l3.add("ABS");
		l3.addAll(l);
		System.out.println(l3);
		

		
	}

}
