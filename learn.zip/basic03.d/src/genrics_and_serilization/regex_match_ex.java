package genrics_and_serilization;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class regex_match_ex {

	public static void main(String[] args) {
		
		Pattern p = Pattern.compile("\\w");
		Matcher m = p.matcher("ababaaabbb");
	
		int count =0;
		
			while(m.find()) {
					count++;
					System.out.println(m.start()+"....."+m.end()+"....."+m.group());
					}
			
			System.out.println("total is : "+count);
			System.out.println(m.groupCount());
		
			
	}
	
}

	

