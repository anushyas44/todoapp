package genrics_and_serilization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class account implements Serializable{
	
	int username = 96260;
	transient String password = "Sarvan@12345";
	
	private void writeObject(ObjectOutputStream o1) throws Exception{
		o1.defaultWriteObject();
		String p1 = "123565"+password;		
		o1.writeObject(p1);
	}

	private void readObject(ObjectInputStream o2) throws Exception{
		o2.defaultReadObject();
		String p1 = (String)o2.readObject();
		password = p1.substring(6);
	}
	
}
public class serail_custom_serial extends account{

	public static void main(String[] args) throws Exception{
		System.out.println("seriliazation started...");
		
		account ac = new account();
		FileOutputStream f1 = new FileOutputStream("abc.txt");
		ObjectOutputStream o1 = new ObjectOutputStream(f1);
		o1.writeObject(ac);
		
		FileInputStream f2 = new FileInputStream("abc.txt");
		ObjectInputStream o2 = new ObjectInputStream(f2);
		Object obj =o2.readObject();
		account a2 = (account)o2.readObject();
		
		if (obj instanceof account) {
			account a =(account)obj;
		System.out.println("Object value is : "+a.username);
		System.out.println("Object value is : "+a.password);
		}
		
//		account a2 = (account)o2.readObject();
//		System.out.println("Object value is : "+a2.password);
		
		
	}

}
