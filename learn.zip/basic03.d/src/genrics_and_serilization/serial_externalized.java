package genrics_and_serilization;

import java.io.Externalizable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

class man implements Externalizable{

	int id = 999888;
	String pas = "AAA@432@";
	
	public man(){
		System.out.println("Contstrucot is callled...");
	}
	
	public void writeExternal(ObjectOutput o1) throws IOException {
		o1.writeInt(id);
		o1.writeObject(pas);
		
	}
	
	public void readExternal(ObjectInput o2) throws IOException, ClassNotFoundException{
		id =o2.readInt();
		pas = (String)o2.readObject();
	}

	
}

public class serial_externalized{

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		man m = new man() ;
		System.out.println("id Value : "+m.id+" Pass value : "+m.pas);
		System.out.println("Seraiization is started...");
		
		FileOutputStream f = new FileOutputStream("abc.txt");
		ObjectOutputStream o1 = new ObjectOutputStream(f);
		o1.writeObject(m);
		
		System.out.println("De--Seraiization is started...");
		
		FileInputStream f2 = new FileInputStream("abc.txt");
		ObjectInputStream o2 = new ObjectInputStream(f2);
		
//		Object obj = o2.readObject();		
//		if(obj instanceof man) {
//			man m2 = (man)obj;
//		}
		
		man m2 =(man)o2.readObject();
		
		
	System.out.println("id Value : "+m2.id+"  Pass value : "+m2.pas);
		
	}

}
