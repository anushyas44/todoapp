package functionalp;

import java.util.Objects;

class client{
	private int id=0;
	
	client(int id){
		this.id= id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}


	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		client other = (client) obj;
		return id == other.id;
	}
		
}

public class jtip {

	public static void main(String[] args) {
	client c1 = new client(2);
	client c2 = new client(2);
	
	System.out.println(c1.equals(c2));

	}

}
