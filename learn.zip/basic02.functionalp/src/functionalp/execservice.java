package functionalp;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Task3 extends Thread{
	
	private int number;

	public Task3(int number) {
		this.number = number;
		
	}
	public void run() {
		System.out.println("Task "+number+" started");
		for (int i=number*100;i<=number*100+99;i++) {
			System.out.print(" "+i);
		}
		System.out.println("Task "+number+" ended");
		
	}
	
}

public class execservice {

	public static void main(String[] args) {

		ExecutorService exservice = Executors.newFixedThreadPool(2);
//		exservice.execute(new Task2());
//		exservice.execute(new Thread(new Task2()));
		
		exservice.execute(new Task3(1));
		exservice.execute(new Task3(2));
		exservice.execute(new Task3(3));
		exservice.execute(new Task3(4));

		
		exservice.shutdown();

	}

}
