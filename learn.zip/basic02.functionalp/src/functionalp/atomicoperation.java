package functionalp;

import java.util.concurrent.atomic.AtomicInteger;

public class atomicoperation {
	
	public AtomicInteger i = new AtomicInteger();
	public AtomicInteger j = new AtomicInteger();
	
	
	public void incrementi() {
		
		//i.set(20);
		i.incrementAndGet();
	}
	
	public int geti() {
		return i.get();
	}

	public static void main(String[] args) {
		
		atomicoperation oper = new atomicoperation();
		oper.incrementi();
		System.out.println(oper.geti());
	}
}
