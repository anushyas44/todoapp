package functionalp;



public class callableex {

	public static void main(String[] args) {
		
		

		String str = null;
		try {
		System.out.println(str.length());
		}
		catch (Exception ex) {
			//ex.printStackTrace();
		}
		finally {
			System.out.println("code completed");
		}
	}

}
