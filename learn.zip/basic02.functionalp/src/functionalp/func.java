package functionalp;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Stream;

class iseven{
	
}


class mapfuc implements Function<Integer, Integer> {

	public Integer apply(Integer num) {
		return num*num;
	}	
}


public class func {
	
	static boolean iseven(Integer num){
		return num%2==0;
	}

	public static void main(String[] args) {
		


		List.of(23,45,67,44,54).stream().map(e->e*e)
		.filter(e ->e%2==0).forEach(e -> System.out.println("element "+e));
		
		List.of(23,45,67,44,54).stream().map(new mapfuc())
		.filter(e ->e%2==0).forEach(e -> System.out.println("element "+e));
		
		List.of(23,45,67,44,54).stream().map(new mapfuc())
		.filter(func::iseven).forEach(e -> System.out.println("element "+e));
		
		//map
		//<R> Stream<R> map(Function<? super T, ? extends R> mapper);
		

	}

}
