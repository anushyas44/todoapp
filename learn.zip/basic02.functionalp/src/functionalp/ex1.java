package functionalp;

import java.util.List;

public class ex1 {

	public static void main(String[] args) {
		List<Integer> numbers = List.of(1,2,3,4,5,7,9);
		
		int sumwithf = numbers.stream().reduce(0, (number1, number2) ->number1+number2);
		System.out.println(sumwithf);
			
		sumWitFunFilter(numbers);
		
		int sum =0;
		for (int num:numbers) {
			sum += num;
		}
		System.out.println("Sum "+sum);
	}

private static void sumWitFunFilter(List<Integer> numbers) {
		int sumwithFilter = numbers.stream().filter(number -> number%2==0).
				reduce(0, (number1, number2) ->number1+number2);
		System.out.println(sumwithFilter);
	}	
}
