package functionalp;

import java.util.Hashtable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAdder;

public class concurrenemap {
	
	public static void main(String[] args) {
		ConcurrentHashMap<String, Integer> occ = new ConcurrentHashMap<>(); 
		 occ.put("A", 100);
		 occ.put("B", 102);
		 occ.put("C", 103);
		 
		 System.out.println("Map size is "+ occ.size());
		 
		 int a = occ.get("A");

		 System.out.println(a);
	}

}
