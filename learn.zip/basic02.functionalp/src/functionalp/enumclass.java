package functionalp;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

enum season{
	WINTER(1),RAIN(4), SUMMER(5);

	int i =0;
	season(int i) {
		this.i=i;
	}
}

public class enumclass {	
	public static void main(String[] args) {
		
		season s1 =season.WINTER;
		
		System.out.println(s1);
		System.out.println(season.values());
		System.out.println(season.SUMMER.ordinal());
		
		System.out.println(Arrays.toString(season.values()));	
	}
}
