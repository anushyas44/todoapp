package functionalp;
import java.util.HashSet;
import java.util.List;

public class functional1 {

	public static void main(String[] args) {

		List<String> list = List.of("Hello", "World", "Java","Apple","Bat","Cat");
		
//		fucnprint(list);
//		print(list);
//		printwitfilter(list);
		fucnprintwithfilter(list);
		
	
	}
	
	private static void fucnprint(List<String> list1) {
		list1.stream().forEach(element -> System.out.println("name "+element));
	}
	

	private static void print(List<String> list1) {
		for(String str:list1) {
			System.out.println(str);
		}
	}
	
		
	private static void printwitfilter(List<String> list1) {
			for(String str:list1) {
				if (str.endsWith("at")) {
					System.out.println("ends with at ="+str);
				}
		}
	}
	
	private static void fucnprintwithfilter(List<String> list) {
				list.stream().filter(element -> element.endsWith("at")).
				forEach(element -> System.out.println("Element -"+element));			
	}
	
}

			
		
	



