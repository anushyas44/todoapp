package functionalp;

class Task1 extends Thread{
	
	public void run() {
		System.out.println("Task 1 started");
		for (int i=100;i<=110;i=i+1) {
			System.out.print(" "+i);
		}
		System.out.println("Task 1 ended");
	}
}

class Task2 implements Runnable{
	
	public void run() {
		System.out.println("Task 2 started");
		for (int i=200;i<=210;i=i+1) {
			System.out.print(" "+i);
		}
		System.out.println("Task 2 ended");
	}
}
public class threads {

	public static void main(String[] args) throws InterruptedException  {

		Task1 task1 = new Task1();
		task1.start();
		task1.setPriority(10);
		task1.sleep(5000);
		
		
		Task2 task2 = new Task2();
		Thread threadrun = new Thread(task2);
		threadrun.start();
		threadrun.setPriority(8);
	
			
		task1.join();
		threadrun.join();
		System.out.println("Task 3 started");
		for (int i=300;i<=310;i=i+1) {
			System.out.print(" "+i);
		}
		

	}

}
