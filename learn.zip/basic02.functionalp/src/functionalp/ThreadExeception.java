package functionalp;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

class currency{
	String currency;
	int money;
	
	public currency(String currency, int money){
		this.currency=currency;
		this.money=money;
	}
	
	void add(currency that) throws Exception {
		if (this.currency==that.currency) {
		this.money= this.money+that.money;
		}
		else {	
			throw new Exception("curreny not matched "+this.currency+" & "+that.currency);
		}
	}
	
	public String toString() {
		return currency+" "+money;
	}
}

public class ThreadExeception {

	public static void main(String[] args) throws Exception {
		
		currency cur1 = new currency("IND", 10);
		currency cur2 = new currency("EUR", 30);
		
		currency cur3 = new currency("IND", 30);

			cur1.add(cur2);

		
		cur1.toString();
		System.out.println(cur1.toString());
		
		
		

		
	}

}
