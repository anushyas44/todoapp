package functionalp;

import java.lang.String;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class counter{
	
	
	private int c=0;
	
	Lock lockwithc = new ReentrantLock();
	
	public void increment() {
		lockwithc.lock();
		c++;
		lockwithc.unlock();
	}
	
	public int get() {
		return c;	
	}	
}


class counterWithD{
	
	private int d=0;
	
	Lock lockwithd = new ReentrantLock();
	
	
	public  void incrementd() {
		lockwithd.lock();
		d++;
		lockwithd.unlock();
	}
	
	public int get() {
		return d;	
	}	
}

public class Synchronization {

	public static void main(String[] args) {
		
		counter count = new counter();
		counterWithD count2 = new counterWithD();

		for (int i=0;i<100;i++) {
			count.increment();
		}
		
		for (int i=0;i<200;i++) {
			count2.incrementd();
		}

		
		Thread t1 = new Thread(() ->{
			for(int i=0;i<100;i++) {
				count.increment();
			}
		});
		
		Thread t2 = new Thread(() ->{
			for(int i=0;i<200;i++) {
				count.increment();
			}
		});
		
		t1.start();

		t2.start();


		
		System.out.println(count.get());
		System.out.println(count2.get());

	}
	
}