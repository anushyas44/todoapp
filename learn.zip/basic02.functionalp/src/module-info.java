/**
 * 
 */
/**
 * 
 */
module functionalp {
}