package api;

import java.util.ArrayList;
import java.util.List;

public class apirunner {

	public static void main(String[] args) {

		List<String> name = new ArrayList<String>();
		name.add("SAM");
		name.add("SK");
		name.add("SARAVANAN");
		
		// list of method is immutable:
//		List<String> name2 = List.of("Hey","Hello");
//		change2(name2);
		
		//Immutable list
		List<String> copyofname = List.copyOf(name);
		
		
		// instead of name -> we can mention copyofname
		change(name);
		
		
		System.out.println(name.toString());
	//System.out.println(name2.toString());
		
		
	}

	static void change(List<String> name) {
		name.add("Value added");
		
	}
	static void change2(List<String> name2) {
		name2.add("added or not");
	}
}
