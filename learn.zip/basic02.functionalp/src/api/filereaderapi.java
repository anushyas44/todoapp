package api;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class filereaderapi {

	public static void main(String[] args) throws IOException  {

		Path path = Paths.get("./resources/testfile.txt");
	
		String filecontent =Files.readString(path);
		//System.out.println(filecontent);
		
		
		//File content replace to another file
		String newcontent = filecontent.replace("SQL", "AAA");
		
		Path newpath = Paths.get("./resources/rewritefile.txt");
		Files.writeString(newpath, newcontent);
		
		//System.out.println(newcontent);
		
		//------------------------------------------------------------
		
		List<String> name = List.of("Hello");
				
	}
}
