package api;

import java.util.Scanner;

class Switchupdatedexp {
	
	String switchrunupdated(int month) {
			
			String monthname = switch (month){
				case 1 -> {
					System.out.println("Some code we can write");
						yield "JAN"; 
				}
				case 2 -> "FEB"; 
				case 3 -> "MAR"; 
				case 4 -> "APR"; 
				default -> throw new IllegalArgumentException("Invalid");
			};
			return monthname;	
		}	
}

class switchexpression {
	
	String switchrun(int month) {
		
		String monthname ="";
		
		switch (month){
			case 1: monthname = "JAN"; break;
			case 2: monthname = "FEB"; break;
			case 3: monthname = "MAR"; break;
			case 4: monthname = "APR"; break;
			default: throw new IllegalArgumentException("Invalid");
		}
		return monthname;	
	}
		
}
public class switchupdated {
	
public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);			
		switchexpression temp1 = new switchexpression();
		
//		System.out.println("enter any num");
//		int num = scan.nextInt();
		
		System.out.println(temp1.switchrun(2));
		
		Switchupdatedexp temp2 = new Switchupdatedexp();
		System.out.println(temp2.switchrunupdated(1));
		
		
	}
	
}

