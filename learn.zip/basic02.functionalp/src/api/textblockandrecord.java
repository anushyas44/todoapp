package api;

public class textblockandrecord {
	
record person(String name, int number, int age) {
		
		static String email="";
		
		person{
			if (name == null) {
				throw new IllegalArgumentException("invalid typ");
			}
		}
		
	}

	public static void main(String[] args) {
		
		person person1 = new person("Saravanan", 96260-51884, 25);
		person person2 = new person("Saravanan", 96260-51884, 25);
		System.out.println(person1);
		System.out.println(person1.equals(person2));

		
		
		String name = """
				
				Text 1
					TEXT 2
						TEXT  3
				""";	
		System.out.println(name);
		
		String text="""
				line 1: %s
				line 2: %s
				line 3:
				""".formatted("hey", "Hello");	
		System.out.println(text);

	}

}
